#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
#include <algorithm>
#define epislon 0.0001
using namespace std;
#include "subbox.h"
#include "mathmethod.h"


/*
4--3
|  |
1--2
*/

int main(){

    vector<subbox> complist;
    vector<subbox> UnitCompList;
    complist = componentlistlol("D:/freespace/McPAT_32x1.flp");
    vector<double> xpartition;
    vector<double> ypartition;

    for (int i=0;i<complist.size();i=i+1){
        if (!ifvaluein(xpartition,complist[i].p1xr())){xpartition.push_back(complist[i].p1xr());}
        if (!ifvaluein(xpartition,complist[i].p2xr())){xpartition.push_back(complist[i].p2xr());}
    }

    for (int i=0;i<complist.size();i=i+1){
        if (!ifvaluein(ypartition,complist[i].p1yr())){ypartition.push_back(complist[i].p1yr());}
        if (!ifvaluein(ypartition,complist[i].p4yr())){ypartition.push_back(complist[i].p4yr());}
    }

    sort (xpartition.begin(), xpartition.end());
    sort (ypartition.begin(), ypartition.end());


    for (int i=0;i<complist.size();i=i+1){
                complist[i].PrintInfo();
        }


    UnitCompList = CreateUnitBox(xpartition,ypartition);
    cout<<endl;

    for (int i=0;i<UnitCompList.size();i=i+1){
                UnitCompList[i].PrintInfo();
        }

    for (int i=0;i<UnitCompList.size();i=i+1){
        if (!ifboxinside(complist,UnitCompList[i])){
                cout<<endl;
                UnitCompList[i].PrintInfo();
                UnitCompList[i].MakeIn();
        }
    }

    cout <<endl<< "xvector contains:";
    for (int i=0;i<xpartition.size();i=i+1){
    cout <<" " << xpartition[i];}
    cout <<endl<< "yvector contains:";
    for (int i=0;i<ypartition.size();i=i+1){
    cout << " " << ypartition[i];}

} //end here
